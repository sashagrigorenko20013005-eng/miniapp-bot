// screens/confirm.js
// Экран подтверждения записи — Premium Beauty Rose Gold Style

import { router } from "../router.js";

export function renderConfirm() {
    const app = document.getElementById("app");

    // Эти данные пока временные (будут приходить из state / backend позже)
    // Сейчас заполняем тестовыми значениями
    const selectedServices = JSON.parse(localStorage.getItem("selectedServices") || "[]");
    const selectedMaster = JSON.parse(localStorage.getItem("selectedMaster") || "{}");
    const selectedDate = localStorage.getItem("selectedDate") || "";
    const selectedTime = localStorage.getItem("selectedTime") || "";

    // Если данных нет → возвращаем на экран услуг
    if (!selectedServices.length || !selectedMaster || !selectedDate || !selectedTime) {
        router.navigate("/services");
        return;
    }

    // Итоговая цена
    const total = selectedServices.reduce((sum, s) => sum + s.price, 0);

    app.innerHTML = `
        <div class="confirm-container fade-in">

            <h2 class="page-title">Подтверждение записи</h2>

            <!-- Карточка записи -->
            <div class="confirm-card">

                <!-- Услуги -->
                <div class="confirm-block">
                    <div class="confirm-title">Услуги</div>
                    ${selectedServices.map(s => `
                        <div class="confirm-row">
                            <span>${s.name}</span>
                            <span class="confirm-price">${s.price} ₽</span>
                        </div>
                    `).join("")}
                </div>

                <div class="confirm-divider"></div>

                <!-- Мастер -->
                <div class="confirm-block">
                    <div class="confirm-title">Мастер</div>
                    <div class="confirm-row">
                        <span>${selectedMaster.name}</span>
                        <span>⭐ ${selectedMaster.rating}</span>
                    </div>
                </div>

                <div class="confirm-divider"></div>

                <!-- Дата и время -->
                <div class="confirm-block">
                    <div class="confirm-title">Дата и время</div>
                    <div class="confirm-row">
                        <span>${selectedDate}</span>
                        <span>${selectedTime}</span>
                    </div>
                </div>

            </div>

            <!-- Итоговая панель -->
            <div class="summary-panel">
                <div class="summary-info">
                    <span class="summary-label">Итого:</span>
                    <span class="summary-total">${total} ₽</span>
                </div>

                <button class="btn-primary" id="confirmBtn">
                    Подтвердить запись
                </button>
            </div>

        </div>
    `;

    // Кнопка подтверждения
    document.getElementById("confirmBtn").onclick = () => {
        // РЕАЛЬНАЯ отправка данных на backend будет позже
        // Сейчас просто показываем экран успеха
        router.navigate("/success");
    };
}
