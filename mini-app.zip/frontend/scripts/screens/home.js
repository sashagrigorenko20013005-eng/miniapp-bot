// screens/home.js
// Главный экран (Home Screen) — Premium Rose Gold Style

import { router } from "../router.js";

export function renderHome() {
    const app = document.getElementById("app");

    // --- Получение данных Telegram пользователя ---
    // При запуске MiniApp Telegram передаёт информацию о юзере.
    const tg = window.Telegram.WebApp;
    const user = tg?.initDataUnsafe?.user || null;

    // На будущее — отправка данных на backend (когда появится)
    // fetch("/api/auth/telegram", { method: "POST", body: JSON.stringify(user) })

    // --- HTML разметка домашнего экрана ---
    app.innerHTML = `
        <div class="home-container fade-in">

            <!-- Название салона -->
            <h1 class="salon-title">Рея</h1>

            <!-- Адрес -->
            <p class="salon-address">Воронеж, улица Димитрова, 47</p>

            <!-- Кнопка перехода к услугам -->
            <button class="btn-primary start-btn" id="startBtn">
                Записаться
            </button>
        </div>
    `;

    // --- Навигация по нажатию кнопки ---
    document.getElementById("startBtn").onclick = () => {
        router.navigate("/services");
    };
}
