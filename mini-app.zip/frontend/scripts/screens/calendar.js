// screens/calendar.js
// Экран выбора даты и времени — Premium Beauty Rose Gold Style

import { router } from "../router.js";

export function renderCalendar() {
    const app = document.getElementById("app");

    // --- Текущая дата ---
    const today = new Date();

    // --- Выбранные пользователем значения ---
    let selectedDate = null;
    let selectedTime = null;

    // --- Создаём диапазон дат (14 дней вперёд) ---
    function generateDates() {
        const dates = [];
        for (let i = 0; i < 14; i++) {
            const date = new Date();
            date.setDate(today.getDate() + i);
            dates.push(date);
        }
        return dates;
    }

    const dates = generateDates();

    // --- Генерация интервалов каждые 30 минут ---
    function generateTimeSlots() {
        const slots = [];
        const start = 8 * 60;   // 08:00
        const end = 18 * 60;    // 18:00

        for (let t = start; t < end; t += 30) {
            const hours = Math.floor(t / 60);
            const minutes = t % 60;
            slots.push(
                `${String(hours).padStart(2, "0")}:${minutes === 0 ? "00" : "30"}`
            );
        }
        return slots;
    }

    const timeSlots = generateTimeSlots();

    // --- HTML ---
    app.innerHTML = `
        <div class="calendar-container fade-in">
            <h2 class="page-title">Выберите дату и время</h2>

            <!-- КАЛЕНДАРЬ -->
            <div class="calendar-strip" id="calendarStrip"></div>

            <!-- СЛОТЫ ВРЕМЕНИ -->
            <div class="time-grid" id="timeGrid"></div>

            <!-- Нижняя панель -->
            <div class="summary-panel">
                <button class="btn-primary" id="continueBtn" disabled>
                    Подтвердить запись
                </button>
            </div>
        </div>
    `;

    const strip = document.getElementById("calendarStrip");
    const grid = document.getElementById("timeGrid");
    const continueBtn = document.getElementById("continueBtn");

    // --- Рендер календаря ---
    function renderCalendarStrip() {
        strip.innerHTML = "";

        dates.forEach(date => {
            const dayNum = date.getDate();
            const weekday = date.toLocaleDateString("ru-RU", { weekday: "short" }).replace(".", "");

            const isSelected =
                selectedDate &&
                date.toDateString() === selectedDate.toDateString();

            const isToday = date.toDateString() === today.toDateString();

            strip.innerHTML += `
                <div class="calendar-item ${isSelected ? "calendar-selected" : ""}" data-date="${date}">
                    <div class="calendar-weekday ${isToday ? "today" : ""}">
                        ${weekday}
                    </div>
                    <div class="calendar-day">${dayNum}</div>
                </div>
            `;
        });

        attachCalendarEvents();
    }

    // --- Рендер слотов времени ---
    function renderTimeSlots() {
        grid.innerHTML = "";

        timeSlots.forEach(time => {
            const isSelected = selectedTime === time;

            grid.innerHTML += `
                <div class="time-slot ${isSelected ? "time-selected" : ""}" data-time="${time}">
                    ${time}
                </div>
            `;
        });

        attachTimeEvents();
    }

    // --- События календаря ---
    function attachCalendarEvents() {
        document.querySelectorAll(".calendar-item").forEach(item => {
            item.onclick = () => {
                selectedDate = new Date(item.dataset.date);
                renderCalendarStrip();
                renderTimeSlots();
                updateContinueBtn();
            };
        });
    }

    // --- События слотов времени ---
    function attachTimeEvents() {
        document.querySelectorAll(".time-slot").forEach(slot => {
            slot.onclick = () => {
                selectedTime = slot.dataset.time;
                renderTimeSlots();
                updateContinueBtn();
            };
        });
    }

    // --- Активация кнопки ---
    function updateContinueBtn() {
        continueBtn.disabled = !(selectedDate && selectedTime);
    }

    continueBtn.onclick = () => {
        // Страница подтверждения
        // Позже добавим передачу данных
        router.navigate("/confirm");
    };

    // Первый рендер
    renderCalendarStrip();
    renderTimeSlots();
}
