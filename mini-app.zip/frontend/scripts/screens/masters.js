// screens/masters.js
// Экран выбора мастера — Premium Beauty Rose Gold Style

import { router } from "../router.js";

export function renderMasters() {
    const app = document.getElementById("app");

    // --- Пример данных мастеров (в будущем — загрузка с backend) ---
    const masters = [
        {
            id: 1,
            name: "Анастасия",
            rating: 4.9,
            experience: "5 лет",
            avatar: "img/master1.png",
        },
        {
            id: 2,
            name: "Мария",
            rating: 4.8,
            experience: "3 года",
            avatar: "img/master2.png",
        },
        {
            id: 3,
            name: "Ольга",
            rating: 4.7,
            experience: "7 лет",
            avatar: "img/master3.png",
        }
    ];

    let selectedMaster = null;

    // --- HTML ---
    app.innerHTML = `
        <div class="masters-container fade-in">
            <h2 class="page-title">Выберите мастера</h2>

            <div id="mastersList"></div>

            <!-- Нижняя панель -->
            <div class="summary-panel">
                <button class="btn-primary" id="continueBtn" disabled>
                    Продолжить
                </button>
            </div>
        </div>
    `;

    const list = document.getElementById("mastersList");
    const continueBtn = document.getElementById("continueBtn");

    // --- Функция рендера карточек мастеров ---
    function renderMastersList() {
        list.innerHTML = "";

        masters.forEach(master => {
            const isSelected = selectedMaster === master.id;

            const card = `
                <div class="master-card ${isSelected ? "master-selected" : ""}" data-id="${master.id}">
                    <img class="master-avatar" src="${master.avatar}" alt="">

                    <div class="master-info">
                        <div class="master-name">${master.name}</div>
                        <div class="master-meta">
                            ⭐ ${master.rating} • Опыт ${master.experience}
                        </div>
                    </div>
                </div>
            `;

            list.innerHTML += card;
        });

        attachEvents();
    }

    // --- События ---
    function attachEvents() {
        document.querySelectorAll(".master-card").forEach(card => {
            card.onclick = () => {
                selectedMaster = Number(card.dataset.id);
                renderMastersList();
                continueBtn.disabled = false;
            };
        });
    }

    continueBtn.onclick = () => {
        // позже будем передавать ID мастера в backend
        router.navigate("/calendar");
    };

    // Первый рендер
    renderMastersList();
}
