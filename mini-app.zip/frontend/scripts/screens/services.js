// screens/services.js
// Экран выбора услуг — Premium Beauty Rose Gold Style

import { router } from "../router.js";

export function renderServices() {
    const app = document.getElementById("app");

    // --- Пример данных категорий и услуг ---
    // Позже всё будет заменено на реальные данные с backend
    const categories = [
        {
            id: 1,
            title: "Парикмахерские услуги",
            opened: false,
            services: [
                { id: 101, name: "Стрижка женская", price: 800, duration: 45, image: "img/hair1.png" },
                { id: 102, name: "Стрижка мужская", price: 600, duration: 30, image: "img/hair2.png" },
            ]
        },
        {
            id: 2,
            title: "Маникюр / Педикюр",
            opened: false,
            services: [
                { id: 201, name: "Маникюр классический", price: 900, duration: 60, image: "img/nails1.png" },
                { id: 202, name: "Покрытие гель-лак", price: 700, duration: 40, image: "img/nails2.png" },
            ]
        },
        {
            id: 3,
            title: "Эстетика лица",
            opened: false,
            services: [
                { id: 301, name: "Чистка лица", price: 1500, duration: 90, image: "img/face1.png" },
            ]
        }
    ];

    // --- Выбранные услуги ---
    let selectedServices = [];

    // --- Функция пересчёта итоговой суммы ---
    function updateSummary() {
        const total = selectedServices.reduce((acc, s) => acc + s.price, 0);
        document.getElementById("summaryTotal").innerText = total + " ₽";
        document.getElementById("summaryBtn").disabled = selectedServices.length === 0;
    }

    // --- HTML разметка ---
    app.innerHTML = `
        <div class="services-container fade-in">
            <h2 class="page-title">Выберите услуги</h2>

            <div id="categoriesList"></div>

            <!-- Нижняя панель с итогом -->
            <div class="summary-panel">
                <div class="summary-info">
                    <span class="summary-label">Итого:</span>
                    <span class="summary-total" id="summaryTotal">0 ₽</span>
                </div>

                <button class="btn-primary summary-btn" id="summaryBtn" disabled>
                    Выбрать мастера
                </button>
            </div>
        </div>
    `;

    // --- Рендер категорий ---
    function renderCategories() {
        const list = document.getElementById("categoriesList");
        list.innerHTML = "";

        categories.forEach(cat => {
            const categoryHTML = `
                <div class="category-card">
                    <div class="category-header" data-id="${cat.id}">
                        <span class="category-title">${cat.title}</span>
                        <span class="category-arrow">${cat.opened ? "▲" : "▼"}</span>
                    </div>

                    <div class="category-body" style="display: ${cat.opened ? "block" : "none"}">
                        ${cat.services.map(service => `
                            <div class="service-card">

                                <!-- Чекбокс -->
                                <input 
                                    type="checkbox" 
                                    class="service-checkbox" 
                                    data-service="${service.id}"
                                    ${selectedServices.find(s => s.id === service.id) ? "checked" : ""}
                                >

                                <!-- Текстовая часть -->
                                <div class="service-info">
                                    <div class="service-name">${service.name}</div>
                                    <div class="service-meta">${service.duration} мин • ${service.price} ₽</div>
                                </div>

                                <!-- Изображение услуги -->
                                <img src="${service.image}" class="service-img">
                            </div>
                        `).join("")}
                    </div>
                </div>
            `;

            list.innerHTML += categoryHTML;
        });

        attachEvents();
    }

    // --- Обработчики событий ---
    function attachEvents() {
        // Открытие / закрытие категории
        document.querySelectorAll(".category-header").forEach(header => {
            header.onclick = () => {
                const id = Number(header.dataset.id);
                const category = categories.find(c => c.id === id);
                category.opened = !category.opened;
                renderCategories();
            };
        });

        // Выбор услуги
        document.querySelectorAll(".service-checkbox").forEach(checkbox => {
            checkbox.onchange = () => {
                const id = Number(checkbox.dataset.service);

                const category = categories.find(c => c.services.find(s => s.id === id));
                const service = category.services.find(s => s.id === id);

                if (checkbox.checked) {
                    selectedServices.push(service);
                } else {
                    selectedServices = selectedServices.filter(s => s.id !== id);
                }

                updateSummary();
            };
        });
    }

    // --- Переход на выбор мастера ---
    document.getElementById("summaryBtn").onclick = () => {
        router.navigate("/masters");
    };

    // Первый рендер
    renderCategories();
    updateSummary();
}
