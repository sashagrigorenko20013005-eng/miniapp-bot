export function SuccessScreen() {
    const container = document.createElement("div");
    container.className = "success-screen";

    container.innerHTML = `
        <div class="success-icon">✔</div>
        <h1>Запись оформлена</h1>
        <p>Спасибо! Мы ждём вас в назначенное время</p>

        <button class="btn-primary" id="backHome">
            На главную
        </button>
    `;

    container.querySelector("#backHome").onclick = () => {
        window.router.go("/");
    };

    return container;
}
